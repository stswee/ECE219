## ECE219_Project1_Final.ipynb
**About**  
Notebook contains code and result for Question 1-7 and Question 9

**Instruction**   
To run this notebook, make sure that the Project1-ClassificationDataset.csv file is in the same directory as this notebook. All cells should be run sequentially.

## ECE219_Project1_Pipeline_Complete.ipynb
**About**  
Notebook contais code and result for Question 8

**Instruction**  
To run this notebook, make sure that the Project1-ClassificationDataset.csv file is in the same directory as this notebook. All cells should be run sequentially. 
If desired, the accuracy_values.txt file can be uploaded in the same directory to avoid having to train all 144 model combinations. Then, start from the cell that uploads the accuracy_values.txt file.

## glove.ipynb
**About**  
Notebook contains code and result for Question 10-13

**Instruction**   
To run this notebook, make sure that the Project1-ClassificationDataset.csv and glove.6B.300d.txt files are in the appropriate directory (change the data path as needed). All cells should be run sequentially.
